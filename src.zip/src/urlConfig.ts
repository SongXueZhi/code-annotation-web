// 后端服务器地址
export const basedIp = '10.177.210.179';

export const basedUrl = `http://${basedIp}:8080/`;
