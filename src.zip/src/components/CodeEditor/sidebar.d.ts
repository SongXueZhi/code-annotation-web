export interface Directory {
  name: string;
  files: { name: string; icon: string }[];
}

export interface Depandency {
  name: string;
}
