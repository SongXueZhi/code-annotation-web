// @ts-nocheck

  import TableOutlined from '@ant-design/icons/es/icons/TableOutlined';
import SmileOutlined from '@ant-design/icons/es/icons/SmileOutlined'
  export default {
    TableOutlined,
SmileOutlined
  }