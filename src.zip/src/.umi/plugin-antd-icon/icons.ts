// @ts-nocheck

import TableOutlined from '@ant-design/icons/TableOutlined';
import SmileOutlined from '@ant-design/icons/SmileOutlined'

export default {
  TableOutlined,
SmileOutlined
}
    