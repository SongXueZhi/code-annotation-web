import _ from '/Users/zhangyifan/project/sxzzz/code-annotation-web/node_modules/antd/es/locale/en_US';
export default _;
