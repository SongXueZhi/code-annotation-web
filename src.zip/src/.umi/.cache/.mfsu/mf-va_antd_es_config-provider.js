import _ from '/Users/zhangyifan/project/sxzzz/code-annotation-web/node_modules/antd/es/config-provider';
export default _;
export * from '/Users/zhangyifan/project/sxzzz/code-annotation-web/node_modules/antd/es/config-provider';
