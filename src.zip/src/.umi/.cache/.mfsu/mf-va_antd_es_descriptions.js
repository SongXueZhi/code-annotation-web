import _ from '/Users/zhangyifan/project/sxzzz/code-annotation-web/node_modules/antd/es/descriptions';
export default _;
export * from '/Users/zhangyifan/project/sxzzz/code-annotation-web/node_modules/antd/es/descriptions';
