import _ from 'events';
export default _;
export * from 'events';
