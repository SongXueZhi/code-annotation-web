import _ from '@ant-design/pro-table';
export default _;
export * from '@ant-design/pro-table';
