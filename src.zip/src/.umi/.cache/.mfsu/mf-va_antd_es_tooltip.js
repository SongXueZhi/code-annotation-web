import _ from '/Users/zhangyifan/project/sxzzz/code-annotation-web/node_modules/antd/es/tooltip';
export default _;
