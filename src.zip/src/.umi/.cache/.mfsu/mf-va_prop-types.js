import _ from 'prop-types';
export default _;
export * from 'prop-types';
