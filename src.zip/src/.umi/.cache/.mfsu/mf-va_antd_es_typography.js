import _ from '/Users/zhangyifan/project/sxzzz/code-annotation-web/node_modules/antd/es/typography';
export default _;
